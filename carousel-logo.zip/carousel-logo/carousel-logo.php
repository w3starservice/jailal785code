<?php
/**
 * Plugin Name:	Carousel Logo Slider
 * Plugin URI:	https://www.test.com/
 * Description: Logo slider display anywhere at your site using shortcode like [cl_logo] 
 * Version:   1.0
 * Author:    Jai
 */

function cl_js_jquery() {
	wp_enqueue_script('jquery');
}
add_action('init', 'cl_js_jquery');

// Include js files
function cl_js_enq_scripts() {
	
	
		wp_register_script('owl-carousel-js', plugins_url('js/owl.carousel.min.js', __FILE__),array('jquery'),'2.3.4', true);
		
		wp_enqueue_script('owl-carousel-js');
	
}
add_action( 'wp_enqueue_scripts', 'cl_js_enq_scripts' ); 


// Include css files
function cl_adding_style() {
	
		wp_register_style('owl-carousel-style', plugins_url('css/owl.carousel.min.css', __FILE__),'','2.3.4', false);
		wp_register_style('owl-theme-style', plugins_url('css/owl.theme.default.min.css', __FILE__),'','2.3.4', false);
				
		wp_enqueue_style('owl-carousel-style');
		wp_enqueue_style('owl-theme-style');
	
}
add_action( 'init', 'cl_adding_style' );

//Registers a new post type

if ( ! function_exists('CL_Logo_Slider')) {

	function CL_Logo_Slider() {

		$labels = array(
			'name'               => _x( 'Logos', 'test' ),
			'singular_name'      => _x( 'Logo', 'test' ),
			'menu_name'          => _x( 'CL Logos', 'admin menu', 'test' ),
			'name_admin_bar'     => _x( 'Logo', 'add new on admin bar', 'test' ),
			'add_new'            => _x( 'Add New Logo', 'logo', 'test' ),
			'add_new_item'       => __( 'Add New Logo', 'test' ),
			'new_item'           => __( 'New Logo', 'test' ),
			'edit_item'          => __( 'Edit Logo', 'test' ),
			'view_item'          => __( 'View Logo', 'test' ),
			'all_items'          => __( 'All Logos', 'test' ),
			'search_items'       => __( 'Search Logos', 'test' ),
			'parent_item_colon'  => __( 'Parent Logos:', 'test' ),
			'not_found'          => __( 'No logos found.', 'test' ),
			'not_found_in_trash' => __( 'No logos found in Trash.', 'test' ),
		);

		$args = array(
				'labels'             => $labels,
				'public'             => true,
				'publicly_queryable' => true,
				'show_ui'            => true,
				'show_in_menu'       => true,
				'query_var'          => true,
				'rewrite'            => array( 'slug' => 'logo' ),
				'capability_type'    => 'post',
				'has_archive'        => false,
				'exclude_from_search' => true,
				'hierarchical'       => false,
				'menu_position'      => 5,
				'menu_icon'          => 'dashicons-screenoptions',
				'supports'           => array( 'title', 'thumbnail' )
			);

			register_post_type( 'cl-logo-slider', $args );
	}
}

add_action( 'init', 'CL_Logo_Slider' );
// Register Theme Features (feature image for Logo)
if ( ! function_exists('cl_logo_theme_support') ) {

	function cl_logo_theme_support()  {\
		add_theme_support( 'post-thumbnails', array( 'cl-logo-slider' ) );
		add_filter('widget_text', 'do_shortcode'); 
	}
	add_action( 'after_setup_theme', 'cl_logo_theme_support' );
}

add_action('do_meta_boxes', 'cl_logo_img_box');
function cl_logo_img_box()
{
    remove_meta_box( 'postimagediv', 'cl-logo-slider', 'side' );
    add_meta_box('postimagediv', __('Company Logo'), 'post_thumbnail_meta_box', 'cl-logo-slider', 'normal', 'high');
}
// plugin setting page
add_action( 'admin_menu', 'cl_plugins_setting' );

function cl_plugins_setting() {
            add_submenu_page( 
                'edit.php?post_type=cl-logo-slider', 
                'CL Setting', 
                'CL Setting', 
                'manage_options', 
                'cl-setting', 
                'cl_setting_menu_cb'
                );
        }
function cl_setting_menu_cb() {
	$updated='';
if(isset($_REQUEST['submit'])){
	update_option('cl_logo_setting',$_REQUEST);
	$updated= '<p class="notice notice-success is-dismissible success">Setting save successfuly!</p>';
}
$cl_logo_setting = get_option('cl_logo_setting');
$speed = ($cl_logo_setting['speed']) ? $cl_logo_setting['speed'] : 250;
$items = ($cl_logo_setting['items']) ? $cl_logo_setting['items'] : 4;
?>
<div id="wpcontent">
<div id="wpbody">
<div id="wpbody-content">
<div class="panel panel-primary panel-default content-panel">
	<div class="panel-body">
	<?php echo $updated; ?>
	<h2>Logo Slider Setting</h2>
	<form id="cl-recommended" method="post" class="layout-form" action="<?php echo admin_url( 'edit.php?post_type=cl-logo-slider&page=cl-setting' ); ?>">
	<input type="number" id="speed" name="speed" min="0" max="50000" value="<?=$speed?>"><br><br>
	<input type="number" id="items" name="items" min="1" max="20" value="<?=$items?>"><br><br>
	<input type="submit" name="submit" value="Sumbit">
	</form>
	</div>
	<p>Logo slider display anywhere at your site using shortcode like: <code> [cl_logo posts='20' order='DESC' orderby='date' title='no']</code> title: no/yes</p>
</div>
</div>
</div>
</div>
<?php	
}

// Shortcode [cl_logo] 

add_shortcode( 'cl_logo', 'cl_logo_shortcode' );

function cl_logo_shortcode( $atts ) {

	extract(shortcode_atts( 
			array(
			'posts' 	=> 20,
			'order'		=> 'DESC',
			'orderby'   => 'date',
			'title'		=> 'no'
			), $atts 
		));

	$loop = new WP_Query(
		array(
			'post_type'	=> 'cl-logo-slider',
			'order'		=> $order,
			'orderby'	=> $orderby,
			'posts_per_page' => $posts
			)
		);

	$output = '<div class="owl-carousel owl-theme cl_logo_container">';
		if ( $loop->have_posts() ) {
			
			while ( $loop->have_posts() ) {
				$loop->the_post();
				$meta = get_post_meta( get_the_id() );
				
				$gs_logo_id = get_post_thumbnail_id();
				$gs_logo_url = wp_get_attachment_image_src($gs_logo_id, array(200,200), true);
				$gs_logo = $gs_logo_url[0];
				$gs_logo_alt = get_post_meta($gs_logo_id,'_wp_attachment_image_alt',true);

				$output .= '<div class="item">';
					

				 	if ($gs_logo) :
						$output .= '<img src="'.$gs_logo.'" alt="'.$gs_logo_alt.'" >';
					endif;
					
					
					if ( $title == "yes" ) :
						$output .= '<h3 class="cl_logo_title">'. get_the_title() .'</h3>';
					endif;
				$output .= '</div>';
			}

		} else {
			$output .= "No Logo Added!";
		}

		wp_reset_postdata();

	$output .= '</div>';

	return $output;
}

// add slider script
add_action('wp_footer','cl_slider_trigger');

function cl_slider_trigger(){
	$cl_logo_setting = get_option('cl_logo_setting');
	$speed = ($cl_logo_setting['speed']) ? $cl_logo_setting['speed'] : 250;
	$items = ($cl_logo_setting['items']) ? $cl_logo_setting['items'] : 4;
?>
<script type="text/javascript">
jQuery(document).ready(function(){
	jQuery('.cl_logo_container').owlCarousel({
		center: true,
		items:<?php echo $items; ?>,
		smartSpeed:<?php echo $speed; ?>,
		loop:true,
		margin:10
	});
});
</script>
<?php
}